# Taby Mint

Asistente flotante para Linux Mint: chat con Ollama + búsqueda de archivos (solo lectura).

## Instalar y ejecutar
```bash
sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget file libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev nodejs npm
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh   # luego abre una terminal nueva
ollama pull llama3.2:3b
cd taby-mint && npm install
CARGO_BUILD_JOBS=2 npm run dev     # la primera compilación tarda varios minutos
```
Si falla alguna librería, revisa los requisitos de Tauri 2 para Debian/Ubuntu en su documentación.
Si Ollama responde 403, inicia su servicio con la variable OLLAMA_ORIGINS="tauri://*".

## Probar
- "ayer descargué un documento llamado registro unico y no lo encuentro"
- "¿cómo instalo un programa en Linux Mint?"
