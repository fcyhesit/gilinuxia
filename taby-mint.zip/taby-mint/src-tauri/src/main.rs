#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::Serialize;
use std::{path::PathBuf, process::Command, time::UNIX_EPOCH};
use walkdir::WalkDir;

#[derive(Serialize)]
struct Archivo {
    nombre: String,
    ruta: String,
    modificado: u64,
}

// Minúsculas, sin tildes y con separadores como espacios: "Registro_Único" -> "registro unico"
fn normalizar(s: &str) -> String {
    s.to_lowercase()
        .chars()
        .map(|c| match c {
            'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' | 'ü' => 'u', 'ñ' => 'n',
            '_' | '-' | '.' => ' ',
            c => c,
        })
        .collect()
}

// Herramienta de solo lectura: busca en la carpeta personal, ignora carpetas ocultas.
#[tauri::command]
fn buscar_archivos(nombre: String, desde: Option<u64>, hasta: Option<u64>) -> Vec<Archivo> {
    let home = std::env::var("HOME").unwrap_or_default();
    let palabras: Vec<String> = normalizar(&nombre).split_whitespace().map(String::from).collect();
    let mut salida = Vec::new();

    let recorrido = WalkDir::new(home).max_depth(6).into_iter().filter_entry(|e| {
        let n = e.file_name().to_string_lossy();
        !(e.depth() > 0 && n.starts_with('.')) && n != "node_modules" && n != "target"
    });

    for e in recorrido.filter_map(Result::ok) {
        if !e.file_type().is_file() {
            continue;
        }
        let nombre_real = e.file_name().to_string_lossy().to_string();
        let normal = normalizar(&nombre_real);
        if !palabras.iter().all(|p| normal.contains(p)) {
            continue;
        }
        let Ok(meta) = e.metadata() else { continue };
        let m = meta
            .modified()
            .ok()
            .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
            .map(|d| d.as_secs())
            .unwrap_or(0);
        if desde.map_or(false, |d| m < d) || hasta.map_or(false, |h| m > h) {
            continue;
        }
        salida.push(Archivo { nombre: nombre_real, ruta: e.path().to_string_lossy().to_string(), modificado: m });
    }
    salida.sort_by(|a, b| b.modificado.cmp(&a.modificado));
    salida.truncate(20);
    salida
}

#[tauri::command]
fn abrir(ruta: String, carpeta: bool) -> Result<(), String> {
    let p = PathBuf::from(&ruta);
    if !p.exists() {
        return Err("El archivo ya no existe".into());
    }
    let objetivo = if carpeta { p.parent().map(|x| x.to_path_buf()).unwrap_or(p) } else { p };
    Command::new("xdg-open").arg(objetivo).spawn().map(|_| ()).map_err(|e| e.to_string())
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![buscar_archivos, abrir])
        .run(tauri::generate_context!())
        .expect("error al iniciar Taby Mint");
}
